import os
import re
import xbmc
import kodiutil
import cinemavision

DEFAULT_3D_RE = '(?i)3DSBS|3D.SBS|HSBS|H.SBS|H-SBS|[\. _]SBS[\. _]|FULL-SBS|FULL.SBS|FULLSBS|FSBS|HALF-SBS|' +\
    '3DTAB|3D.TAB|HTAB|H.TAB|3DOU|3D.OU|3D.HOU|[\. _]HOU[\. _]|[\. _]OU[\. _]|HALF-TAB|[\. _]TAB[\. _]'

cinemavision.init(kodiutil.DEBUG(), kodiutil.Progress, kodiutil.T, kodiutil.getSetting('3D.tag.regex', DEFAULT_3D_RE))


def defaultSavePath():
    return os.path.join(kodiutil.ADDON_PATH, 'resources', 'script.cinemavision.default.cvseq')


def lastSavePath():
    name = kodiutil.getSetting('save.name', '')
    return getSavePath(name)


def getSavePath(name):
    contentPath = kodiutil.getSetting('content.path')
    if not name or not contentPath:
        return

    return cinemavision.util.pathJoin(contentPath, 'Sequences', name + '.cvseq')


def getSequencePath(for_3D=False):
    if for_3D:
        name = kodiutil.getSetting('sequence.3D')
    else:
        name = kodiutil.getSetting('sequence.2D')

    if name:
        return getSavePath(name)

    return defaultSavePath()


def selectSequence():
    import xbmcgui

    contentPath = kodiutil.getSetting('content.path')
    if not contentPath:
        xbmcgui.Dialog().ok('Not Found', ' ', 'No sequences found.')
        return None

    sequencesPath = cinemavision.util.pathJoin(contentPath, 'Sequences')
    options = cinemavision.util.vfs.listdir(sequencesPath)
    if not options:
        xbmcgui.Dialog().ok('Not Found', ' ', 'No sequences found.')
        return None

    idx = xbmcgui.Dialog().select('Choose Sequence', [n[:-6] for n in options])
    if idx < 0:
        return None
    path = cinemavision.util.pathJoin(sequencesPath, options[idx])

    return {'path': path, 'name': options[idx][:-6]}


def getDBPath(from_load=False):
    dbPath = None
    if not kodiutil.getSetting('content.path'):
        dbPath = os.path.join(kodiutil.PROFILE_PATH, 'demo')
        if not os.path.exists(dbPath):
            copyDemoContent()
            downloadDemoContent()
            if not from_load:
                loadContent()
        return dbPath
    return None


def loadContent(from_settings=False):
    import xbmcgui

    contentPath = kodiutil.getSetting('content.path')
    if from_settings and not contentPath:
        xbmcgui.Dialog().ok('No Content Path', ' ', 'Content path not set or not applied')
        return

    dbPath = getDBPath(from_load=True)
    if contentPath:
        kodiutil.setSetting('content.initialized', True)
    else:
        contentPath = os.path.join(kodiutil.PROFILE_PATH, 'demo')

    kodiutil.DEBUG_LOG('Loading content...')

    with kodiutil.Progress('Loading Content') as p:
        cinemavision.content.UserContent(contentPath, callback=p.msg, db_path=dbPath,  trailer_sources=kodiutil.getSetting('trailer.scrapers', '').split(','))

    createSettingsRSDirs()


def createSettingsRSDirs():
    base = os.path.join(kodiutil.PROFILE_PATH, 'settings', 'ratings')
    if not os.path.exists(base):
        os.makedirs(base)
    defaultPath = os.path.join(kodiutil.PROFILE_PATH, 'settings', 'ratings_default')

    if os.path.exists(defaultPath):
        import shutil
        shutil.rmtree(defaultPath)

    defaultSystem = kodiutil.getSetting('rating.system.default', 'MPAA')

    for system in cinemavision.ratings.RATINGS_SYSTEMS.values():
        systemPaths = [os.path.join(base, system.name)]
        if system.name == defaultSystem:
            systemPaths.append(defaultPath)

        for path in systemPaths:
            if not os.path.exists(path):
                os.makedirs(path)

            for rating in system.ratings:
                with open(os.path.join(path, str(rating).replace(':', '.', 1)), 'w'):
                    pass

    kodiutil.setSetting('settings.ratings.initialized', 'true')
    kodiutil.setSetting('settings.ratings.initialized2', 'true')


def downloadDemoContent():
    import xbmc
    import requests
    import zipfile
    url = 'http://cinemavision.tv/cvdemo/Demo.zip'
    output = os.path.join(kodiutil.PROFILE_PATH, 'demo.zip')
    target = os.path.join(kodiutil.PROFILE_PATH, 'demo', 'Trivia Slides')
    # if not os.path.exists(target):
    #     os.makedirs(target)

    with open(output, 'wb') as handle:
        response = requests.get(url, stream=True)
        total = float(response.headers.get('content-length', 1))
        sofar = 0
        blockSize = 4096
        if not response.ok:
            return False

        with kodiutil.Progress('Download', 'Downloading demo content') as p:
            for block in response.iter_content(blockSize):
                sofar += blockSize
                pct = int((sofar/total) * 100)
                p.update(pct)
                handle.write(block)

    z = zipfile.ZipFile(output)
    z.extractall(target)
    xbmc.sleep(500)
    try:
        os.remove(output)
    except:
        kodiutil.ERROR()

    return True


def copyDemoContent():
    source = os.path.join(kodiutil.ADDON_PATH, 'resources', 'demo')
    dest = os.path.join(kodiutil.PROFILE_PATH, 'demo')
    import shutil
    shutil.copytree(source, dest)


def setRatingBumperStyle():
    import xbmcgui

    styles = cinemavision.sequence.Feature.DBChoices('ratingStyle')

    if not styles:
        xbmcgui.Dialog().ok('No Content', '', 'No content found for current rating system.')
        return

    idx = xbmcgui.Dialog().select('Select Style', [x[1] for x in styles])

    if idx < 0:
        return

    kodiutil.setSetting('feature.ratingStyle', styles[idx][0])

_RATING_PARSER = None


def ratingParser():
    global _RATING_PARSER
    if not _RATING_PARSER:
        _RATING_PARSER = RatingParser()
    return _RATING_PARSER


class RatingParser:
    SYSTEM_RATING_REs = {
        # 'MPAA': r'(?i)^Rated\s(?P<rating>Unrated|NR|PG-13|PG|G|R|NC-17)',
        'BBFC': r'(?i)^UK(?:\s+|:)(?P<rating>Uc|U|12A|12|PG|15|R18|18)',
        'FSK': r'(?i)^(?:FSK|Germany)(?:\s+|:)(?P<rating>0|6|12|16|18|Unrated)',
        'DEJUS': r'(?i)(?P<rating>Livre|10 Anos|12 Anos|14 Anos|16 Anos|18 Anos)'
    }

    RATING_REs = {
        'MPAA': r'(?i)(?P<rating>Unrated|NR|PG-13|PG|G|R|NC-17)',
        'BBFC': r'(?i)(?P<rating>Uc|U|12A|12|PG|15|R18|18)',
        'FSK': r'(?i)(?P<rating>0|6|12|16|18|Unrated)',
        'DEJUS': r'(?i)(?P<rating>Livre|10 Anos|12 Anos|14 Anos|16 Anos|18 Anos)'
    }

    SYSTEM_RATING_REs.update(cinemavision.ratings.getRegExs('kodi'))
    RATING_REs.update(cinemavision.ratings.getRegExs())

    LANGUAGE = xbmc.getLanguage(xbmc.ISO_639_1, region=True)

    def __init__(self):
        kodiutil.DEBUG_LOG('Language: {0}'.format(self.LANGUAGE))
        self.setRatingDefaults()

    def setRatingDefaults(self):
        ratingSystem = kodiutil.getSetting('rating.system.default', 'MPAA')

        if not ratingSystem:
            try:
                countryCode = self.LANGUAGE.split('-')[1].strip()
                if countryCode:
                    cinemavision.ratings.setCountry(countryCode)
            except IndexError:
                pass
            except:
                kodiutil.ERROR()
        else:
            cinemavision.ratings.setDefaultRatingSystem(ratingSystem)

    def getActualRatingFromMPAA(self, rating, debug=False):
        if debug:
            kodiutil.DEBUG_LOG('Rating from Kodi: {0}'.format(repr(rating)))

        if not rating:
            return 'UNKNOWN:NR'

        # Try a definite match
        for system, ratingRE in self.SYSTEM_RATING_REs.items():
            m = re.search(ratingRE, rating)
            if m:
                return '{0}:{1}'.format(system, m.group('rating'))

        rating = rating.upper().replace('RATED', '').strip(': ')

        # Try to match against default system if set
        defaultSystem = cinemavision.ratings.DEFAULT_RATING_SYSTEM
        if defaultSystem and defaultSystem in self.RATING_REs:
            m = re.search(self.RATING_REs[defaultSystem], rating)
            if m:
                return '{0}:{1}'.format(defaultSystem, m.group('rating'))

        # Try to extract rating from know ratings systems
        for system, ratingRE in self.RATING_REs.items():
            m = re.search(ratingRE, rating)
            if m:
                return m.group('rating')

        # Just return what we have
        return rating


def multiSelect(options, default=False):
    import kodigui

    class ModuleMultiSelectDialog(kodigui.MultiSelectDialog):
        xmlFile = 'script.cinemavision-multi-select-dialog.xml'
        path = kodiutil.ADDON_PATH
        theme = 'Main'
        res = '1080i'

        OPTIONS_LIST_ID = 300
        OK_BUTTON_ID = 201
        CANCEL_BUTTON_ID = 202
        USE_DEFAULT_BUTTON_ID = 203
        HELP_TEXTBOX_ID = 250

        TOGGLE_MOVE_DIVIDER_X = 190

    w = ModuleMultiSelectDialog.open(options=options, default=default)
    result = w.result
    del w
    if result:
        return ','.join(result)

    return result
